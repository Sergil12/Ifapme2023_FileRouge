export interface ContractDto{
   contract_id:string;
   title:string;
   description:string;
   start_date:Date;
   end_date:Date;
   nb_hours_by_week:number;

}
