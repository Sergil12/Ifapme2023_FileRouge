export interface DocumentDto{
 document_id:string;
 title:string;
 path:string;
 content:string;
 type:string;
 create_date:Date;
}
