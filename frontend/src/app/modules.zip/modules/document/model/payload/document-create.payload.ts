export interface DocumentCreatePayload{
  title:string;
  path:string;
  content:string;
  type:string;
  create_date:number;
}
