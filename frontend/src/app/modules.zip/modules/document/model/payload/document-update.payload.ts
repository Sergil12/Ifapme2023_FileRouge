export interface DocumentUpdatePayload{
  document_id:string;
  title:string;
  path:string;
  content:string;
  type:string;
  create_date:number;
}
