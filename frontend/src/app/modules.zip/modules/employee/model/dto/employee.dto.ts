export interface EmployeeDto{
  employee_id:string;
  lastname:string;
  firstname:string;
  active:boolean;
  deleted_by:string;
  address:string;
  gender:string;
  birthday:Date;
  ssin:string;
  status:string;
  deleted:boolean ;
}
