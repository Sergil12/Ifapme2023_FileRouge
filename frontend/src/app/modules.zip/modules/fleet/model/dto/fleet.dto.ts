// ici le contenu du fleet.java

export interface FleetDto{
   fleet_id:string;
   title:string;
   description:string;
   type:string;
   cost:number;
}
