// FleetCreatePayload.java
export interface FleetCreatePayload{
   title:string;
  description:string;
  type:string;
  cost:number;
}
