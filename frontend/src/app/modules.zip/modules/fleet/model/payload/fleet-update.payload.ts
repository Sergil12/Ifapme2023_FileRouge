// FleetUpdatePayload.ts
export interface FleetUpdatePayload{
  fleet_id:string;
  title:string;
  description:string;
  type:string;
  cost:number;
}
