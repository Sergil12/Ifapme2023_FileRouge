export interface OrganizationDto{
  organization_id:string;
  name:string;
  description:string;
}
