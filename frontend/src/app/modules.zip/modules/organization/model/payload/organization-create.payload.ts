export interface OrganizationCreatePayload{
  name:string;
  description:string;
}
