export interface OrganizationUpdatePayload{
  organization_id:string;
  name:string;
  description:string;
}
