export interface SalaryDto{
 salary_id:string;
 create_date:Date;
 title:string
 comment:string
 amount:number;
}
