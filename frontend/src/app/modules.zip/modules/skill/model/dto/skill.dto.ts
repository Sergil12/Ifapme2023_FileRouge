export interface SkillDto{
  skill_id:string;
  title:string;
  description:string;
}
