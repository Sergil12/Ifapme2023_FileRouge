export interface SkillCreatePayload{
  title:string;
  description:string;
}
