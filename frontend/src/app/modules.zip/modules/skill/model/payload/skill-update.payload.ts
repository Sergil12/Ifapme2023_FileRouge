export interface SkillUpdatePayload{
  skill_id:string;
  title:string;
  description:string;
}
