import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TimeSheetRoutingModule } from './time-sheet-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TimeSheetRoutingModule
  ]
})
export class TimeSheetModule { }
